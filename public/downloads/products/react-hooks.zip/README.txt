Placeholder download file. Replace with real product later.
